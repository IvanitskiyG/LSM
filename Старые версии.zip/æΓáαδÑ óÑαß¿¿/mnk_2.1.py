import os
os.system('color 0a')
print('Метод наименьших квадратов v2.1')
print('©IGS Software, 2023\n')
import matplotlib.pyplot as plt


def get_input():
    while True:
        s = input().strip().replace(',', '.')
        lx = []
        ly = []
        if len(s) >= 4 and s[:4].lower() == 'from':
            filename = s[4:].strip()
            f = open(filename, 'r')
            for line in f.readlines():
                x, y = map(float, line.replace(',', '.').split())
                print(x, y)
                lx.append(x)
                ly.append(y)
            f.close()
            print('Введены данные из файла', filename)
            return lx, ly
        if s.lower() == 'exit':
            return 'EXIT'
        while s != '':
            if s.count(' ') != 1:
                print('Некорректные данные, повторите ввод')
                continue
            x, y = map(float, s.split())
            lx.append(x)
            ly.append(y)
            s = input().strip().replace(',', '.')
        return lx, ly


while True:
    print('Вводите x и y через пробел\nПустая строка - конец ввода данных\nEXIT - выход\nFROM имя_файла - ввод из файла')
    lx = []
    ly = []
    inp = get_input()
    if inp == 'EXIT':
        break
    lx, ly = inp
    n = len(lx)
    a = 0
    b = 0
    for i in range(n):
        a += lx[i] * ly[i]
        b += lx[i] ** 2
    k = (a * n - sum(lx) * sum(ly)) / (b * n - sum(lx) ** 2)
    b = (sum(ly) - k * sum(lx)) / n
    rc = 0; sy2 = 0; sx2 = 0
    for i in range(n):
        rc += lx[i] * ly[i]
        sx2 += lx[i] ** 2
        sy2 += ly[i] ** 2
    rc = rc * n - sum(lx) * sum(ly)
    rz = ((n * sx2 - sum(lx) ** 2) * (n * sy2 - sum(ly) ** 2)) ** 0.5
    r = rc / rz
    print('y = kx + b')
    print('k =', k)
    print('b =', b)
    print('Коэффициент корелляции ', r)
    if 0.98 < abs(r) and abs(r) < 1:
        print('Данные хорошо ложатся на прямую')
    print('Построение графика...\n')
    ty = [k * x + b for x in lx]
    plt.title('Исходные данные и приближение')
    plt.xlabel('x')
    plt.ylabel('y1, y2')
    plt.grid()
    plt.scatter(lx, ly)
    plt.plot(lx, ty, '-')
    plt.show()
