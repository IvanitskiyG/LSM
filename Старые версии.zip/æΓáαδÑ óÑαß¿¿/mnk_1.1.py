print('Метод наименьших квадратов v1.1')
print('©IGS Software, 2022\n')
ex = False

def get_input():
    while True:
        s = input().strip()
        s = s.replace(',', '.')
        if s == '':
            return 'END_OF_DATA'
        if s == 'EXIT':
            return 'EXIT'
        if s.count(' ') == 1:
            return map(float, s.split())
        print('Некорректные данные, повторите ввод')

'''
Ввод с файла
'''
while True:
    print('Вводите x и y через пробел\nПустая строка - конец ввода данных\nEXIT - выход')
    lx = []
    ly = []
    while True:    
        inp = get_input()
        if inp == 'END_OF_DATA':
            break
        if inp == 'EXIT':
            ex = True
            break
        x, y = inp
        lx.append(x)
        ly.append(y)
    if ex:
        break
    n = len(lx)
    a = 0
    b = 0
    for i in range(n):
        a += lx[i] * ly[i]
        b += lx[i] ** 2
    k = (a * n - sum(lx) * sum(ly)) / (b * n - sum(lx) ** 2)
    b = (sum(ly) - k * sum(lx)) / n
    print('y = kx + b')
    print('k =', k)
    print('b =', b)
