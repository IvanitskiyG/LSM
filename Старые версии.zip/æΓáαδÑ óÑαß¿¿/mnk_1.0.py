print('Метод наименьших квадратов v1.0')
print('©IGS Software, 2022')
'''
Ввод с файла
Нормальный выход из программы
'''
while True:
    print('Вводите x и y через пробел; пустая строка = конец ввода данных')
    lx = []
    ly = []
    while True:    
        s = input().strip()
        if s == '':
            break
        x, y = map(float, s.split())
        lx.append(x)
        ly.append(y)
    n = len(lx)
    a = 0
    b = 0
    for i in range(n):
        a += lx[i] * ly[i]
        b += lx[i] ** 2
    k = (a * n - sum(lx) * sum(ly)) / (b * n - sum(lx) ** 2)
    b = (sum(ly) - k * sum(lx)) / n
    print('y = kx + b')
    print('k =', k)
    print('b =', b)
